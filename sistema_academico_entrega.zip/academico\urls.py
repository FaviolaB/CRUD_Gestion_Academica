from django.urls import path
from . import views

app_name = "academico"

urlpatterns = [
    path("", views.InicioView.as_view(), name="inicio"),

    # Estudiantes
    path("estudiantes/", views.EstudianteListView.as_view(), name="estudiante_lista"),
    path("estudiantes/crear/", views.EstudianteCreateView.as_view(), name="estudiante_crear"),
    path("estudiantes/<int:pk>/", views.EstudianteDetailView.as_view(), name="estudiante_detalle"),
    path("estudiantes/<int:pk>/editar/", views.EstudianteUpdateView.as_view(), name="estudiante_editar"),
    path("estudiantes/<int:pk>/eliminar/", views.EstudianteDeleteView.as_view(), name="estudiante_eliminar"),

    # Matrículas
    path("matriculas/", views.MatriculaListView.as_view(), name="matricula_lista"),
    path("matriculas/crear/", views.MatriculaCreateView.as_view(), name="matricula_crear"),
    path("matriculas/<int:pk>/", views.MatriculaDetailView.as_view(), name="matricula_detalle"),
    path("matriculas/<int:pk>/pdf/", views.MatriculaPdfView.as_view(), name="matricula_pdf"),
    path("matriculas/<int:pk>/editar/", views.MatriculaUpdateView.as_view(), name="matricula_editar"),
    path("matriculas/<int:pk>/eliminar/", views.MatriculaDeleteView.as_view(), name="matricula_eliminar"),

    # Profesores
    path("profesores/", views.ProfesorListView.as_view(), name="profesor_lista"),
    path("profesores/crear/", views.ProfesorCreateView.as_view(), name="profesor_crear"),
    path("profesores/<int:pk>/", views.ProfesorDetailView.as_view(), name="profesor_detalle"),
    path("profesores/<int:pk>/pdf/", views.ProfesorPdfView.as_view(), name="profesor_pdf"),
    path("profesores/<int:pk>/editar/", views.ProfesorUpdateView.as_view(), name="profesor_editar"),
    path("profesores/<int:pk>/eliminar/", views.ProfesorDeleteView.as_view(), name="profesor_eliminar"), # Universidades
    path("universidades/", views.UniversidadListView.as_view(), name="universidad_lista"),
    path("universidades/crear/", views.UniversidadCreateView.as_view(), name="universidad_crear"),
    path("universidades/<int:pk>/", views.UniversidadDetailView.as_view(), name="universidad_detalle"),
    path("universidades/<int:pk>/pdf/", views.UniversidadPdfView.as_view(), name="universidad_pdf"),
    path("universidades/<int:pk>/editar/", views.UniversidadUpdateView.as_view(), name="universidad_editar"),
    path("universidades/<int:pk>/eliminar/", views.UniversidadDeleteView.as_view(), name="universidad_eliminar"),

    # Facultades
    path("facultades/", views.FacultadListView.as_view(), name="facultad_lista"),
    path("facultades/crear/", views.FacultadCreateView.as_view(), name="facultad_crear"),
    path("facultades/<int:pk>/", views.FacultadDetailView.as_view(), name="facultad_detalle"),
    path("facultades/<int:pk>/pdf/", views.FacultadPdfView.as_view(), name="facultad_pdf"),
    path("facultades/<int:pk>/editar/", views.FacultadUpdateView.as_view(), name="facultad_editar"),
    path("facultades/<int:pk>/eliminar/", views.FacultadDeleteView.as_view(), name="facultad_eliminar"),

    # Carreras
    path("carreras/", views.CarreraListView.as_view(), name="carrera_lista"),
    path("carreras/crear/", views.CarreraCreateView.as_view(), name="carrera_crear"),
    path("carreras/<int:pk>/", views.CarreraDetailView.as_view(), name="carrera_detalle"),
    path("carreras/<int:pk>/pdf/", views.CarreraPdfView.as_view(), name="carrera_pdf"),
    path("carreras/<int:pk>/editar/", views.CarreraUpdateView.as_view(), name="carrera_editar"),
    path("carreras/<int:pk>/eliminar/", views.CarreraDeleteView.as_view(), name="carrera_eliminar"),# Semestres
    path("semestres/", views.SemestreListView.as_view(), name="semestre_lista"),
    path("semestres/crear/", views.SemestreCreateView.as_view(), name="semestre_crear"),
    path("semestres/<int:pk>/", views.SemestreDetailView.as_view(), name="semestre_detalle"),
    path("semestres/<int:pk>/pdf/", views.SemestrePdfView.as_view(), name="semestre_pdf"),
    path("semestres/<int:pk>/editar/", views.SemestreUpdateView.as_view(), name="semestre_editar"),
    path("semestres/<int:pk>/eliminar/", views.SemestreDeleteView.as_view(), name="semestre_eliminar"),

    # Periodos
    path("periodos/", views.PeriodoListView.as_view(), name="periodo_lista"),
    path("periodos/crear/", views.PeriodoCreateView.as_view(), name="periodo_crear"),
    path("periodos/<int:pk>/", views.PeriodoDetailView.as_view(), name="periodo_detalle"),
    path("periodos/<int:pk>/pdf/", views.PeriodoPdfView.as_view(), name="periodo_pdf"),
    path("periodos/<int:pk>/editar/", views.PeriodoUpdateView.as_view(), name="periodo_editar"),
    path("periodos/<int:pk>/eliminar/", views.PeriodoDeleteView.as_view(), name="periodo_eliminar"),

    # Cursos
    path("cursos/", views.CursoListView.as_view(), name="curso_lista"),
    path("cursos/crear/", views.CursoCreateView.as_view(), name="curso_crear"),
    path("cursos/<int:pk>/", views.CursoDetailView.as_view(), name="curso_detalle"),
    path("cursos/<int:pk>/pdf/", views.CursoPdfView.as_view(), name="curso_pdf"),
    path("cursos/<int:pk>/editar/", views.CursoUpdateView.as_view(), name="curso_editar"),
    path("cursos/<int:pk>/eliminar/", views.CursoDeleteView.as_view(), name="curso_eliminar"),
    path("cursos/<int:pk>/eliminar/", views.CursoDeleteView.as_view(), name="curso_eliminar"),           # Secciones
    path("secciones/", views.SeccionListView.as_view(), name="seccion_lista"),
    path("secciones/crear/", views.SeccionCreateView.as_view(), name="seccion_crear"),
    path("secciones/<int:pk>/", views.SeccionDetailView.as_view(), name="seccion_detalle"),
    path("secciones/<int:pk>/pdf/", views.SeccionPdfView.as_view(), name="seccion_pdf"),
    path("secciones/<int:pk>/editar/", views.SeccionUpdateView.as_view(), name="seccion_editar"),
    path("secciones/<int:pk>/eliminar/", views.SeccionDeleteView.as_view(), name="seccion_eliminar"),

    path("secciones/<int:pk>/eliminar/", views.SeccionDeleteView.as_view(), name="seccion_eliminar"),
    path(
        "secciones/<int:pk>/matricular-varios/",
        views.matricular_varios,
        name="matricular_varios",
    ),
    path("secciones/<int:pk>/registrar-notas/", views.registrar_notas_seccion, name="registrar_notas_seccion"),
]
