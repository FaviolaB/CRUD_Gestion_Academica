from django import forms
from django.db.models import Count
from django.forms import inlineformset_factory
from .models import (
    Carrera,
    Curso,
    EstadoNota,
    Estudiante,
    Facultad,
    Jornada,
    Matricula,
    Nota,
    Periodo,
    Profesor,
    Seccion,
    Semestre,
    Universidad,
)


class BootstrapFormMixin:
    """Aplica clases de Bootstrap 5 a todos los campos del formulario."""
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field in self.fields.values():
            widget = field.widget
            if isinstance(widget, forms.CheckboxInput):
                widget.attrs.setdefault("class", "form-check-input")
            elif isinstance(widget, forms.Select):
                widget.attrs.setdefault("class", "form-select")
            else:
                widget.attrs.setdefault("class", "form-control")


class EstudianteForm(BootstrapFormMixin, forms.ModelForm):
    class Meta:
        model = Estudiante
        fields = [
            "cedula",
            "nombres",
            "apellidos",
            "email",
            "telefono",
            "fecha_nacimiento",
            "carrera",
            "foto",
        ]
        widgets = {
            "fecha_nacimiento": forms.DateInput(attrs={"type": "date"}),
        }

    def clean_cedula(self):
        cedula = self.cleaned_data.get("cedula", "").strip()
        if not cedula.isdigit() or len(cedula) != 10:
            raise forms.ValidationError("La cédula debe tener exactamente 10 números.")
        return cedula


class FiltroEstudianteForm(BootstrapFormMixin, forms.Form):
    texto = forms.CharField(
        label="Buscar",
        required=False,
        widget=forms.TextInput(attrs={"placeholder": "Cédula, nombres o apellidos..."}),
    )
    carrera = forms.ModelChoiceField(
        label="Carrera",
        queryset=Carrera.objects.all(),
        required=False,
        empty_label="Todas las carreras",
    )
    facultad = forms.ModelChoiceField(
        label="Facultad",
        queryset=Facultad.objects.all(),
        required=False,
        empty_label="Todas las facultades",
    )
    nacido_desde = forms.DateField(
        label="Nacido desde",
        required=False,
        widget=forms.DateInput(attrs={"type": "date"}),
    )
    nacido_hasta = forms.DateField(
        label="Nacido hasta",
        required=False,
        widget=forms.DateInput(attrs={"type": "date"}),
    )


class SeccionChoiceField(forms.ModelChoiceField):
    def label_from_instance(self, obj):
        curso = getattr(obj.curso, "codigo", str(obj.curso))
        sec = getattr(obj, "paralelo", getattr(obj, "codigo", getattr(obj, "nombre", "")))
        jornada = obj.get_jornada_display() if hasattr(obj, "get_jornada_display") else getattr(obj, "jornada", "")
        periodo = getattr(obj.periodo, "nombre", getattr(obj.periodo, "codigo", str(obj.periodo)))
        inscritos = getattr(obj, "num_inscritos", obj.matriculas.count())
        cupo = getattr(obj, "cupo", getattr(obj, "cupo_maximo", 0))
        return f"{curso} {sec} · {jornada} · {periodo} ({inscritos}/{cupo})"


class MatriculaForm(BootstrapFormMixin, forms.ModelForm):
    seccion = SeccionChoiceField(
        label="Sección",
        queryset=Seccion.objects.none(),
    )

    class Meta:
        model = Matricula
        fields = ["estudiante", "seccion", "fecha"]
        widgets = {
            "fecha": forms.DateInput(attrs={"type": "date"}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        qs = (
            Seccion.objects.filter(periodo__activo=True)
            .select_related("curso", "periodo")
            .annotate(num_inscritos=Count("matriculas"))
        )
        if self.instance and self.instance.pk and self.instance.seccion_id:
            qs = (
                (Seccion.objects.filter(periodo__activo=True) | Seccion.objects.filter(pk=self.instance.seccion_id))
                .distinct()
                .select_related("curso", "periodo")
                .annotate(num_inscritos=Count("matriculas"))
            )
        self.fields["seccion"].queryset = qs


class NotaInlineForm(BootstrapFormMixin, forms.ModelForm):
    class Meta:
        model = Nota
        fields = ["n1", "n2", "n3"]


NotaFormSet = inlineformset_factory(
    Matricula,
    Nota,
    form=NotaInlineForm,
    fields=["n1", "n2", "n3"],
    extra=1,
    max_num=1,
    can_delete=False,
)


class FiltroMatriculaForm(BootstrapFormMixin, forms.Form):
    texto = forms.CharField(
        label="Buscar estudiante",
        required=False,
        widget=forms.TextInput(attrs={"placeholder": "Cédula o apellido..."}),
    )
    periodo = forms.ModelChoiceField(
        label="Periodo",
        queryset=Periodo.objects.all(),
        required=False,
        empty_label="Todos los periodos",
    )
    carrera = forms.ModelChoiceField(
        label="Carrera",
        queryset=Carrera.objects.all(),
        required=False,
        empty_label="Todas las carreras",
    )
    curso = forms.ModelChoiceField(
        label="Curso",
        queryset=Curso.objects.all(),
        required=False,
        empty_label="Todos los cursos",
    )
    jornada = forms.ChoiceField(
        label="Jornada",
        choices=[("", "Todas las jornadas")] + list(Jornada.choices),
        required=False,
    )
    estado = forms.ChoiceField(
        label="Estado",
        choices=[("", "Todos los estados")] + list(EstadoNota.choices),
        required=False,
    )
    promedio_desde = forms.DecimalField(
        label="Promedio desde",
        required=False,
        decimal_places=2,
        widget=forms.NumberInput(attrs={"step": "0.01", "placeholder": "0.00"}),
    )
    promedio_hasta = forms.DecimalField(
        label="Promedio hasta",
        required=False,
        decimal_places=2,
        widget=forms.NumberInput(attrs={"step": "0.01", "placeholder": "100.00"}),
    )


class ProfesorForm(BootstrapFormMixin, forms.ModelForm):
    class Meta:
        model = Profesor
        fields = ["cedula", "nombres", "apellidos", "email", "titulo"]

    def clean_cedula(self):
        cedula = self.cleaned_data.get("cedula", "").strip()
        if not cedula.isdigit() or len(cedula) != 10:
            raise forms.ValidationError("La cédula debe tener exactamente 10 números.")
        return cedula


class FiltroProfesorForm(BootstrapFormMixin, forms.Form):
    texto = forms.CharField(
        label="Buscar",
        required=False,
        widget=forms.TextInput(attrs={"placeholder": "Cédula o apellidos..."}),
    )
    periodo = forms.ModelChoiceField(
        label="Periodo",
        queryset=Periodo.objects.all(),
        required=False,
        empty_label="Todos los periodos",
    )# ========================
# FORMULARIOS ESTRUCTURA
# ========================
class UniversidadForm(BootstrapFormMixin, forms.ModelForm):
    class Meta:
        model = Universidad
        fields = ["nombre", "siglas", "ciudad", "logo"]


class FiltroUniversidadForm(BootstrapFormMixin, forms.Form):
    texto = forms.CharField(
        label="Buscar",
        required=False,
        widget=forms.TextInput(attrs={"placeholder": "Nombre o siglas..."}),
    )
    ciudad = forms.CharField(
        label="Ciudad",
        required=False,
        widget=forms.TextInput(attrs={"placeholder": "Ciudad..."}),
    )


class FacultadForm(BootstrapFormMixin, forms.ModelForm):
    class Meta:
        model = Facultad
        fields = ["universidad", "nombre", "decano"]


class FiltroFacultadForm(BootstrapFormMixin, forms.Form):
    universidad = forms.ModelChoiceField(
        label="Universidad",
        queryset=Universidad.objects.all(),
        required=False,
        empty_label="Todas las universidades",
    )
    texto = forms.CharField(
        label="Buscar",
        required=False,
        widget=forms.TextInput(attrs={"placeholder": "Nombre de facultad o decano..."}),
    )


class CarreraForm(BootstrapFormMixin, forms.ModelForm):
    class Meta:
        model = Carrera
        fields = ["facultad", "codigo", "nombre", "duracion_semestres"]

    def clean_codigo(self):
        return self.cleaned_data.get("codigo", "").strip().upper()


class FiltroCarreraForm(BootstrapFormMixin, forms.Form):
    universidad = forms.ModelChoiceField(
        label="Universidad",
        queryset=Universidad.objects.all(),
        required=False,
        empty_label="Todas las universidades",
    )
    facultad = forms.ModelChoiceField(
        label="Facultad",
        queryset=Facultad.objects.all(),
        required=False,
        empty_label="Todas las facultades",
    )
    texto = forms.CharField(
        label="Buscar",
        required=False,
        widget=forms.TextInput(attrs={"placeholder": "Código o nombre..."}),
    )# ========================
# FORMULARIOS CATÁLOGO
# ========================
class SemestreForm(BootstrapFormMixin, forms.ModelForm):
    class Meta:
        model = Semestre
        fields = ["numero", "nombre"]

    def clean_numero(self):
        numero = self.cleaned_data.get("numero")
        if numero is not None and (numero < 1 or numero > 12):
            raise forms.ValidationError("El número de semestre debe estar entre 1 y 12.")
        return numero


class PeriodoForm(BootstrapFormMixin, forms.ModelForm):
    class Meta:
        model = Periodo
        fields = ["nombre", "fecha_inicio", "fecha_fin", "activo"]
        widgets = {
            "fecha_inicio": forms.DateInput(attrs={"type": "date"}),
            "fecha_fin": forms.DateInput(attrs={"type": "date"}),
        }


class FiltroPeriodoForm(BootstrapFormMixin, forms.Form):
    activo = forms.ChoiceField(
        label="Estado",
        choices=[("", "Todos"), ("1", "Activo"), ("0", "Inactivo")],
        required=False,
    )
    anio = forms.IntegerField(
        label="Año",
        required=False,
        widget=forms.NumberInput(attrs={"placeholder": "Ej. 2026"}),
    )


class CursoForm(BootstrapFormMixin, forms.ModelForm):
    class Meta:
        model = Curso
        fields = ["carrera", "semestre", "codigo", "nombre", "creditos"]

    def clean_codigo(self):
        return self.cleaned_data.get("codigo", "").strip().upper()


class FiltroCursoForm(BootstrapFormMixin, forms.Form):
    carrera = forms.ModelChoiceField(
        label="Carrera",
        queryset=Carrera.objects.all(),
        required=False,
        empty_label="Todas las carreras",
    )
    semestre = forms.ModelChoiceField(
        label="Semestre",
        queryset=Semestre.objects.all(),
        required=False,
        empty_label="Todos los semestres",
    )
    texto = forms.CharField(
        label="Buscar",
        required=False,
        widget=forms.TextInput(attrs={"placeholder": "Código o nombre..."}),
    )# ========================
# FORMULARIOS ACADÉMICO (SECCIÓN)
# ========================
class SeccionForm(BootstrapFormMixin, forms.ModelForm):
    class Meta:
        model = Seccion
        fields = ["curso", "periodo", "profesor", "paralelo", "jornada", "cupo"]

    def clean_paralelo(self):
        return self.cleaned_data.get("paralelo", "").strip().upper()


class FiltroSeccionForm(BootstrapFormMixin, forms.Form):
    periodo = forms.ModelChoiceField(
        label="Periodo",
        queryset=Periodo.objects.all(),
        required=False,
        empty_label="Todos los periodos",
    )
    carrera = forms.ModelChoiceField(
        label="Carrera",
        queryset=Carrera.objects.all(),
        required=False,
        empty_label="Todas las carreras",
    )
    jornada = forms.ChoiceField(
        label="Jornada",
        choices=[("", "Todas las jornadas")] + list(Jornada.choices),
        required=False,
    )
    profesor = forms.ModelChoiceField(
        label="Profesor",
        queryset=Profesor.objects.all(),
        required=False,
        empty_label="Todos los profesores",
    )