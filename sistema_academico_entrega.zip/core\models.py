# =====================================================================
# core/models.py · el molde que heredan TODOS los modelos del sistema
# =====================================================================
from django.contrib.auth.models import User
from django.db import models


class ModeloBase(models.Model):
    # Guardamos qué usuario registró o modificó el dato por última vez.
    # editable=False oculta este campo en los formularios automáticos.
    # %(app_label)s_%(class)s crea un related_name único por cada modelo hijo.
    user = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        editable=False,
        related_name="%(app_label)s_%(class)s_registrados",
        verbose_name="Registrado por",
    )
    # auto_now_add guarda la fecha y hora solo cuando se crea el registro.
    fecha_creacion = models.DateTimeField("Fecha de creación", auto_now_add=True)
    # auto_now actualiza la fecha y hora cada vez que se guarda el registro.
    fecha_modificacion = models.DateTimeField("Última modificación", auto_now=True)

    class Meta:
        abstract = True  # Indica que es solo una plantilla base y no crea tabla en SQLite.