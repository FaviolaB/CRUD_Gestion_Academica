
# Register your models here.
from django.contrib import admin
from .models import (
    Universidad, Facultad, Carrera, Semestre, Periodo,
    Curso, Profesor, Estudiante, Seccion, Matricula, Nota
)


class BaseAdmin(admin.ModelAdmin):
    """Clase base para mostrar campos de auditoría en solo lectura y guardar el usuario."""
    readonly_fields = ("user", "fecha_creacion", "fecha_modificacion")

    def save_model(self, request, obj, form, change):
        # Guarda automáticamente el usuario que creó o editó el registro
        obj.user = request.user
        super().save_model(request, obj, form, change)


@admin.register(Universidad)
class UniversidadAdmin(BaseAdmin):
    list_display = ("siglas", "nombre", "ciudad", "fecha_creacion")
    search_fields = ("nombre", "siglas", "ciudad")


@admin.register(Facultad)
class FacultadAdmin(BaseAdmin):
    list_display = ("nombre", "universidad", "decano")
    list_filter = ("universidad",)
    search_fields = ("nombre", "decano")


@admin.register(Carrera)
class CarreraAdmin(BaseAdmin):
    list_display = ("codigo", "nombre", "facultad", "duracion_semestres")
    list_filter = ("facultad__universidad", "facultad")
    search_fields = ("codigo", "nombre")


@admin.register(Semestre)
class SemestreAdmin(BaseAdmin):
    list_display = ("numero", "nombre")
    ordering = ("numero",)


@admin.register(Periodo)
class PeriodoAdmin(BaseAdmin):
    list_display = ("nombre", "fecha_inicio", "fecha_fin", "activo")
    list_filter = ("activo",)
    search_fields = ("nombre",)


@admin.register(Curso)
class CursoAdmin(BaseAdmin):
    list_display = ("codigo", "nombre", "carrera", "semestre", "creditos")
    list_filter = ("carrera", "semestre")
    search_fields = ("codigo", "nombre")


@admin.register(Profesor)
class ProfesorAdmin(BaseAdmin):
    list_display = ("cedula", "apellidos", "nombres", "titulo", "email")
    search_fields = ("cedula", "apellidos", "nombres")


@admin.register(Estudiante)
class EstudianteAdmin(BaseAdmin):
    list_display = ("cedula", "apellidos", "nombres", "carrera", "email")
    list_filter = ("carrera",)
    search_fields = ("cedula", "apellidos", "nombres")


@admin.register(Seccion)
class SeccionAdmin(BaseAdmin):
    list_display = ("curso", "periodo", "paralelo", "jornada", "profesor", "cupo", "inscritos")
    list_filter = ("periodo", "jornada", "curso__carrera")
    search_fields = ("curso__nombre", "curso__codigo", "profesor__apellidos")


class NotaInline(admin.StackedInline):
    """Permite registrar o editar la Nota directamente dentro de Matrícula."""
    model = Nota
    max_num = 1
    extra = 1
    readonly_fields = ("promedio", "estado", "user", "fecha_creacion", "fecha_modificacion")


@admin.register(Matricula)
class MatriculaAdmin(BaseAdmin):
    list_display = ("estudiante", "seccion", "fecha")
    list_filter = ("seccion__periodo", "seccion__jornada", "seccion__curso__carrera")
    search_fields = ("estudiante__cedula", "estudiante__apellidos", "seccion__curso__nombre")
    inlines = [NotaInline]


@admin.register(Nota)
class NotaAdmin(BaseAdmin):
    list_display = ("matricula", "n1", "n2", "n3", "promedio", "estado")
    list_filter = ("estado", "matricula__seccion__periodo")
    search_fields = ("matricula__estudiante__cedula", "matricula__estudiante__apellidos")
    readonly_fields = ("promedio", "estado", "user", "fecha_creacion", "fecha_modificacion")