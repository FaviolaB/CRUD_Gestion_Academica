from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin, PermissionRequiredMixin
from django.contrib.messages.views import SuccessMessageMixin
from django.db import transaction
from django.db.models import Avg, Count, ProtectedError, Q
from django.urls import reverse_lazy
from django.views.generic import CreateView, DeleteView, DetailView, ListView, TemplateView, UpdateView
from django.utils.text import slugify
from django import forms
from django.contrib.auth.decorators import login_required
from django.core.exceptions import ValidationError
from django.shortcuts import get_object_or_404, redirect, render
from .forms import NotaInlineForm

from core.mixins import ComprobantePdfMixin, ExportarMixin, UsuarioRegistroMixin
from core.utils import renderizar_pdf
from .forms import (
    CarreraForm,
    CursoForm,
    EstudianteForm,
    FacultadForm,
    FiltroCarreraForm,
    FiltroCursoForm,
    FiltroEstudianteForm,
    FiltroFacultadForm,
    FiltroMatriculaForm,
    FiltroPeriodoForm,
    FiltroProfesorForm,
    FiltroSeccionForm,
    FiltroUniversidadForm,
    MatriculaForm,
    NotaFormSet,
    PeriodoForm,
    ProfesorForm,
    SeccionForm,
    SemestreForm,
    UniversidadForm,
)
from .models import (
    Carrera,
    Curso,
    EstadoNota,
    Estudiante,
    Facultad,
    Matricula,
    Nota,
    Periodo,
    Profesor,
    Seccion,
    Semestre,
    Universidad,
)
class InicioView(LoginRequiredMixin, TemplateView):
    template_name = "academico/inicio.html"

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        periodo_activo = Periodo.objects.filter(activo=True).first()
        secciones_activas = (
            Seccion.objects.filter(periodo=periodo_activo).count()
            if periodo_activo
            else Seccion.objects.count()
        )
        total_notas = Nota.objects.count()
        aprobados = Nota.objects.filter(estado=EstadoNota.APROBADO).count()
        porcentaje_aprobados = round((aprobados / total_notas) * 100, 1) if total_notas > 0 else 0

        ctx["periodo_activo"] = periodo_activo
        ctx["total_estudiantes"] = Estudiante.objects.count()
        ctx["total_secciones"] = secciones_activas
        ctx["total_matriculas"] = Matricula.objects.count()
        ctx["porcentaje_aprobados"] = porcentaje_aprobados
        notas_periodo = Nota.objects.filter(
            matricula__seccion__periodo=periodo_activo
        ) if periodo_activo else Nota.objects.none()

        ctx["aprobados_periodo"] = notas_periodo.filter(
            estado=EstadoNota.APROBADO
        ).count()
        ctx["reprobados_periodo"] = notas_periodo.filter(
            estado=EstadoNota.REPROBADO
        ).count() 
        return ctx

# ========================
# CRUD ESTUDIANTES
# ========================
class EstudianteListView(LoginRequiredMixin, ExportarMixin, ListView):
    model = Estudiante
    template_name = "academico/estudiante_lista.html"
    context_object_name = "estudiantes"
    paginate_by = 10
    filtro_form_class = FiltroEstudianteForm
    titulo_reporte = "Reporte de estudiantes"
    nombre_archivo = "estudiantes"
    campos_disponibles = [
        ("cedula", "Cédula"),
        ("apellidos", "Apellidos"),
        ("nombres", "Nombres"),
        ("email", "Correo"),
        ("telefono", "Teléfono"),
        ("fecha_nacimiento", "Nacimiento"),
        ("carrera__nombre", "Carrera"),
        ("carrera__facultad__nombre", "Facultad"),
    ]
    campos_por_defecto = [
        "cedula",
        "apellidos",
        "nombres",
        "email",
        "carrera__nombre",
    ]

    def get_queryset(self):
        return super().get_queryset().select_related("carrera__facultad")

    def get_nombre_archivo(self):
        nombre = super().get_nombre_archivo()
        if self.filtro_form is None or not self.filtro_form.is_valid():
            return nombre

        carrera = self.filtro_form.cleaned_data.get("carrera")
        if carrera:
            return f"{nombre}-{slugify(carrera.nombre)}"

        return nombre
    
    def filtrar(self, queryset, datos):
        texto = datos.get("texto")
        if texto:
            queryset = queryset.filter(
                Q(nombres__icontains=texto)
                | Q(apellidos__icontains=texto)
                | Q(cedula__icontains=texto)
            )
        if datos.get("carrera"):
            queryset = queryset.filter(carrera=datos["carrera"])
        if datos.get("facultad"):
            queryset = queryset.filter(carrera__facultad=datos["facultad"])
        if datos.get("nacido_desde"):
            queryset = queryset.filter(fecha_nacimiento__gte=datos["nacido_desde"])
        if datos.get("nacido_hasta"):
            queryset = queryset.filter(fecha_nacimiento__lte=datos["nacido_hasta"])
        return queryset


class EstudianteCreateView(LoginRequiredMixin, UsuarioRegistroMixin, SuccessMessageMixin, CreateView):
    model = Estudiante
    form_class = EstudianteForm
    template_name = "academico/estudiante_form.html"
    success_url = reverse_lazy("academico:estudiante_lista")
    success_message = "Estudiante creado correctamente."


class EstudianteUpdateView(LoginRequiredMixin, UsuarioRegistroMixin, SuccessMessageMixin, UpdateView):
    model = Estudiante
    form_class = EstudianteForm
    template_name = "academico/estudiante_form.html"
    success_url = reverse_lazy("academico:estudiante_lista")
    success_message = "Estudiante actualizado correctamente."


class EstudianteDetailView(LoginRequiredMixin, DetailView):
    model = Estudiante
    template_name = "academico/estudiante_detalle.html"
    context_object_name = "estudiante"

    def get_queryset(self):
        return super().get_queryset().select_related("carrera__facultad__universidad")

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx["matriculas"] = self.object.matriculas.select_related(
            "seccion__curso", "seccion__periodo", "seccion__profesor"
        ).prefetch_related("nota")

        ctx["promedio_general"] = self.object.matriculas.aggregate(
            general=Avg("nota__promedio")
        )["general"]

        return ctx

    def render_to_response(self, context, **response_kwargs):
        if self.request.GET.get("formato") == "pdf":
            return renderizar_pdf(
                "pdf/ficha_estudiante.html",
                context,
                nombre_archivo=f"ficha_{self.object.cedula}",
            )
        return super().render_to_response(context, **response_kwargs)


class EstudianteDeleteView(LoginRequiredMixin, PermissionRequiredMixin, DeleteView):
    permission_required = "academico.delete_estudiante"
    model = Estudiante
    template_name = "academico/estudiante_eliminar.html"
    context_object_name = "estudiante"
    success_url = reverse_lazy("academico:estudiante_lista")

    def form_valid(self, form):
        try:
            response = super().form_valid(form)
        except ProtectedError:
            messages.error(
                self.request,
                "No se puede eliminar al estudiante porque tiene matrículas registradas.",
            )
            return redirect(self.success_url)

        messages.success(self.request, "Estudiante eliminado correctamente.")
        return response


# ========================
# CRUD MATRÍCULA + NOTA
# ========================
class MatriculaNotaMixin:
    """Gestiona en una misma transacción el formulario maestro (Matricula) y su detalle (Nota)."""
    model = Matricula
    form_class = MatriculaForm
    template_name = "academico/matricula_form.html"
    success_url = reverse_lazy("academico:matricula_lista")

    def get_nota_formset(self):
        if self.request.method == "POST":
            return NotaFormSet(self.request.POST, instance=self.object)
        return NotaFormSet(instance=self.object)

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        if "nota_formset" not in ctx:
            ctx["nota_formset"] = self.get_nota_formset()
        return ctx

    def post(self, request, *args, **kwargs):
        self.object = None if isinstance(self, CreateView) else self.get_object()
        form = self.get_form()
        nota_formset = NotaFormSet(self.request.POST, instance=self.object)
        if form.is_valid() and nota_formset.is_valid():
            return self.form_valid(form, nota_formset)
        return self.form_invalid(form, nota_formset)

    def form_valid(self, form, nota_formset):
        with transaction.atomic():
            if hasattr(form.instance, "user"):
                form.instance.user = self.request.user
            elif hasattr(form.instance, "usuario_registro"):
                form.instance.usuario_registro = self.request.user

            self.object = form.save()
            nota_formset.instance = self.object
            notas = nota_formset.save(commit=False)
            for nota in notas:
                if hasattr(nota, "user"):
                    nota.user = self.request.user
                elif hasattr(nota, "usuario_registro"):
                    nota.usuario_registro = self.request.user
                nota.save()
            nota_formset.save_m2m()

        messages.success(self.request, getattr(self, "success_message", "Matrícula y nota guardadas correctamente."))
        return redirect(self.get_success_url())

    def form_invalid(self, form, nota_formset):
        return self.render_to_response(
            self.get_context_data(form=form, nota_formset=nota_formset)
        )


class MatriculaListView(LoginRequiredMixin, ExportarMixin, ListView):
    model = Matricula
    template_name = "academico/matricula_lista.html"
    context_object_name = "matriculas"
    paginate_by = 10
    filtro_form_class = FiltroMatriculaForm
    titulo_reporte = "Reporte de matrículas y notas"
    nombre_archivo = "matriculas"
    campos_disponibles = [
        ("estudiante__cedula", "Cédula"),
        ("estudiante", "Estudiante"),
        ("seccion__curso__nombre", "Curso"),
        ("seccion__paralelo", "Paralelo"),
        ("seccion__jornada", "Jornada"),
        ("seccion__periodo__nombre", "Periodo"),
        ("seccion__profesor", "Profesor"),
        ("nota__n1", "Nota 1"),
        ("nota__n2", "Nota 2"),
        ("nota__n3", "Nota 3"),
        ("nota__promedio", "Promedio"),
        ("nota__estado", "Estado"),
        ("fecha", "Fecha"),
    ]
    campos_por_defecto = [
        "estudiante__cedula",
        "estudiante",
        "seccion__curso__nombre",
        "seccion__jornada",
        "nota__promedio",
        "nota__estado",
    ]

    def get_queryset(self):
        return (
            super()
            .get_queryset()
            .select_related(
                "estudiante",
                "seccion__curso__carrera",
                "seccion__periodo",
                "seccion__profesor",
                "nota",
            )
        )

    def filtrar(self, queryset, datos):
        texto = datos.get("texto")
        if texto:
            queryset = queryset.filter(
                Q(estudiante__cedula__icontains=texto)
                | Q(estudiante__apellidos__icontains=texto)
            )
        if datos.get("periodo"):
            queryset = queryset.filter(seccion__periodo=datos["periodo"])
        if datos.get("carrera"):
            queryset = queryset.filter(seccion__curso__carrera=datos["carrera"])
        if datos.get("curso"):
            queryset = queryset.filter(seccion__curso=datos["curso"])
        if datos.get("jornada"):
            queryset = queryset.filter(seccion__jornada=datos["jornada"])
        if datos.get("estado"):
            queryset = queryset.filter(nota__estado=datos["estado"])
        if datos.get("promedio_desde") is not None:
            queryset = queryset.filter(nota__promedio__gte=datos["promedio_desde"])
        if datos.get("promedio_hasta") is not None:
            queryset = queryset.filter(nota__promedio__lte=datos["promedio_hasta"])
        return queryset


class MatriculaCreateView(LoginRequiredMixin, MatriculaNotaMixin, CreateView):
    success_message = "Matrícula y nota registradas correctamente."


class MatriculaUpdateView(LoginRequiredMixin, MatriculaNotaMixin, UpdateView):
    success_message = "Matrícula y nota actualizadas correctamente."


class MatriculaDetailView(LoginRequiredMixin, DetailView):
    model = Matricula
    template_name = "academico/matricula_detalle.html"
    context_object_name = "matricula"

    def get_queryset(self):
        return (
            super()
            .get_queryset()
            .select_related("estudiante__carrera", "seccion__curso", "seccion__periodo", "seccion__profesor", "nota")
        )


class MatriculaDeleteView(LoginRequiredMixin, SuccessMessageMixin, DeleteView):
    model = Matricula
    template_name = "academico/matricula_eliminar.html"
    context_object_name = "matricula"
    success_url = reverse_lazy("academico:matricula_lista")
    success_message = "Matrícula eliminada correctamente."


class MatriculaPdfView(LoginRequiredMixin, ComprobantePdfMixin, DetailView):
    model = Matricula
    context_object_name = "matricula"
    template_pdf = "pdf/matricula_comprobante.html"
    nombre_archivo = "matricula"

    def get_queryset(self):
        return (
            super()
            .get_queryset()
            .select_related(
                "estudiante__carrera__facultad__universidad",
                "seccion__curso",
                "seccion__periodo",
                "seccion__profesor",
                "nota",
            )
        )


# ========================
# CRUD PROFESORES
# ========================
class ProfesorListView(LoginRequiredMixin, ExportarMixin, ListView):
    model = Profesor
    template_name = "academico/profesor_lista.html"
    context_object_name = "profesores"
    paginate_by = 10
    filtro_form_class = FiltroProfesorForm
    titulo_reporte = "Reporte de profesores"
    nombre_archivo = "profesores"
    campos_disponibles = [
        ("cedula", "Cédula"),
        ("apellidos", "Apellidos"),
        ("nombres", "Nombres"),
        ("titulo", "Título"),
        ("email", "Correo"),
    ]
    campos_por_defecto = [
        "cedula",
        "apellidos",
        "nombres",
        "titulo",
        "email",
    ]

    def filtrar(self, queryset, datos):
        texto = datos.get("texto")
        if texto:
            queryset = queryset.filter(
                Q(cedula__icontains=texto)
                | Q(apellidos__icontains=texto)
            )
        if datos.get("periodo"):
            queryset = queryset.filter(secciones__periodo=datos["periodo"]).distinct()
        return queryset


class ProfesorCreateView(LoginRequiredMixin, UsuarioRegistroMixin, SuccessMessageMixin, CreateView):
    model = Profesor
    form_class = ProfesorForm
    template_name = "academico/profesor_form.html"
    success_url = reverse_lazy("academico:profesor_lista")
    success_message = "Profesor creado correctamente."


class ProfesorUpdateView(LoginRequiredMixin, UsuarioRegistroMixin, SuccessMessageMixin, UpdateView):
    model = Profesor
    form_class = ProfesorForm
    template_name = "academico/profesor_form.html"
    success_url = reverse_lazy("academico:profesor_lista")
    success_message = "Profesor actualizado correctamente."


class ProfesorDetailView(LoginRequiredMixin, DetailView):
    model = Profesor
    template_name = "academico/profesor_detalle.html"
    context_object_name = "profesor"

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        periodo_activo = Periodo.objects.filter(activo=True).first()
        secciones = self.object.secciones.select_related("curso", "periodo")
        if periodo_activo:
            secciones = secciones.filter(periodo=periodo_activo)
        ctx["periodo_activo"] = periodo_activo
        ctx["secciones"] = secciones
        return ctx


class ProfesorDeleteView(LoginRequiredMixin, DeleteView):
    model = Profesor
    template_name = "academico/profesor_eliminar.html"
    context_object_name = "profesor"
    success_url = reverse_lazy("academico:profesor_lista")

    def form_valid(self, form):
        try:
            response = super().form_valid(form)
            messages.success(self.request, "Profesor eliminado correctamente.")
            return response
        except ProtectedError:
            messages.error(self.request, "No se puede eliminar: tiene secciones asignadas.")
            return redirect(self.success_url)


class ProfesorPdfView(LoginRequiredMixin, ComprobantePdfMixin, DetailView):
    model = Profesor
    context_object_name = "profesor"
    template_pdf = "pdf/profesor_comprobante.html"
    nombre_archivo = "profesor"

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        periodo_activo = Periodo.objects.filter(activo=True).first()
        secciones = self.object.secciones.select_related("curso", "periodo")
        if periodo_activo:
            secciones = secciones.filter(periodo=periodo_activo)
        ctx["periodo_activo"] = periodo_activo
        ctx["secciones"] = secciones
        return ctx                                                                                             # ========================
# CRUD UNIVERSIDADES
# ========================
class UniversidadListView(LoginRequiredMixin, ExportarMixin, ListView):
    model = Universidad
    template_name = "academico/universidad_lista.html"
    context_object_name = "universidades"
    paginate_by = 10
    filtro_form_class = FiltroUniversidadForm
    titulo_reporte = "Reporte de universidades"
    nombre_archivo = "universidades"
    campos_disponibles = [
        ("siglas", "Siglas"),
        ("nombre", "Nombre"),
        ("ciudad", "Ciudad"),
        ("num_facultades", "N.º de facultades"),
    ]
    campos_por_defecto = ["siglas", "nombre", "ciudad", "num_facultades"]

    def get_queryset(self):
        return super().get_queryset().annotate(num_facultades=Count("facultades"))

    def filtrar(self, queryset, datos):
        texto = datos.get("texto")
        if texto:
            queryset = queryset.filter(Q(nombre__icontains=texto) | Q(siglas__icontains=texto))
        if datos.get("ciudad"):
            queryset = queryset.filter(ciudad__icontains=datos["ciudad"])
        return queryset


class UniversidadCreateView(LoginRequiredMixin, UsuarioRegistroMixin, SuccessMessageMixin, CreateView):
    model = Universidad
    form_class = UniversidadForm
    template_name = "academico/universidad_form.html"
    success_url = reverse_lazy("academico:universidad_lista")
    success_message = "Universidad creada correctamente."


class UniversidadUpdateView(LoginRequiredMixin, UsuarioRegistroMixin, SuccessMessageMixin, UpdateView):
    model = Universidad
    form_class = UniversidadForm
    template_name = "academico/universidad_form.html"
    success_url = reverse_lazy("academico:universidad_lista")
    success_message = "Universidad actualizada correctamente."


class UniversidadDetailView(LoginRequiredMixin, DetailView):
    model = Universidad
    template_name = "academico/universidad_detalle.html"
    context_object_name = "universidad"

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx["facultades"] = self.object.facultades.prefetch_related("carreras")
        return ctx


class UniversidadDeleteView(LoginRequiredMixin, DeleteView):
    model = Universidad
    template_name = "academico/universidad_eliminar.html"
    context_object_name = "universidad"
    success_url = reverse_lazy("academico:universidad_lista")

    def form_valid(self, form):
        try:
            response = super().form_valid(form)
            messages.success(self.request, "Universidad eliminada correctamente.")
            return response
        except ProtectedError:
            messages.error(self.request, "No se puede eliminar: tiene facultades registradas.")
            return redirect(self.success_url)


class UniversidadPdfView(LoginRequiredMixin, ComprobantePdfMixin, DetailView):
    model = Universidad
    context_object_name = "universidad"
    template_pdf = "pdf/universidad_comprobante.html"
    nombre_archivo = "universidad"

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx["facultades"] = self.object.facultades.prefetch_related("carreras")
        return ctx


# ========================
# CRUD FACULTADES
# ========================
class FacultadListView(LoginRequiredMixin, ExportarMixin, ListView):
    model = Facultad
    template_name = "academico/facultad_lista.html"
    context_object_name = "facultades"
    paginate_by = 10
    filtro_form_class = FiltroFacultadForm
    titulo_reporte = "Reporte de facultades"
    nombre_archivo = "facultades"
    campos_disponibles = [
        ("universidad__siglas", "Universidad"),
        ("nombre", "Facultad"),
        ("decano", "Decano"),
    ]
    campos_por_defecto = ["universidad__siglas", "nombre", "decano"]

    def get_queryset(self):
        return super().get_queryset().select_related("universidad")

    def filtrar(self, queryset, datos):
        if datos.get("universidad"):
            queryset = queryset.filter(universidad=datos["universidad"])
        texto = datos.get("texto")
        if texto:
            queryset = queryset.filter(Q(nombre__icontains=texto) | Q(decano__icontains=texto))
        return queryset


class FacultadCreateView(LoginRequiredMixin, UsuarioRegistroMixin, SuccessMessageMixin, CreateView):
    model = Facultad
    form_class = FacultadForm
    template_name = "academico/facultad_form.html"
    success_url = reverse_lazy("academico:facultad_lista")
    success_message = "Facultad creada correctamente."


class FacultadUpdateView(LoginRequiredMixin, UsuarioRegistroMixin, SuccessMessageMixin, UpdateView):
    model = Facultad
    form_class = FacultadForm
    template_name = "academico/facultad_form.html"
    success_url = reverse_lazy("academico:facultad_lista")
    success_message = "Facultad actualizada correctamente."


class FacultadDetailView(LoginRequiredMixin, DetailView):
    model = Facultad
    template_name = "academico/facultad_detalle.html"
    context_object_name = "facultad"

    def get_queryset(self):
        return super().get_queryset().select_related("universidad")

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx["carreras"] = self.object.carreras.all()
        return ctx


class FacultadDeleteView(LoginRequiredMixin, DeleteView):
    model = Facultad
    template_name = "academico/facultad_eliminar.html"
    context_object_name = "facultad"
    success_url = reverse_lazy("academico:facultad_lista")

    def form_valid(self, form):
        try:
            response = super().form_valid(form)
            messages.success(self.request, "Facultad eliminada correctamente.")
            return response
        except ProtectedError:
            messages.error(self.request, "No se puede eliminar: tiene carreras registradas.")
            return redirect(self.success_url)


class FacultadPdfView(LoginRequiredMixin, ComprobantePdfMixin, DetailView):
    model = Facultad
    context_object_name = "facultad"
    template_pdf = "pdf/facultad_comprobante.html"
    nombre_archivo = "facultad"

    def get_queryset(self):
        return super().get_queryset().select_related("universidad")

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx["carreras"] = self.object.carreras.all()
        return ctx


# ========================
# CRUD CARRERAS
# ========================
class CarreraListView(LoginRequiredMixin, ExportarMixin, ListView):
    model = Carrera
    template_name = "academico/carrera_lista.html"
    context_object_name = "carreras"
    paginate_by = 10
    filtro_form_class = FiltroCarreraForm
    titulo_reporte = "Reporte de carreras"
    nombre_archivo = "carreras"
    campos_disponibles = [
        ("codigo", "Código"),
        ("nombre", "Carrera"),
        ("facultad__nombre", "Facultad"),
        ("duracion_semestres", "Duración (semestres)"),
    ]
    campos_por_defecto = ["codigo", "nombre", "facultad__nombre", "duracion_semestres"]

    def get_queryset(self):
        return super().get_queryset().select_related("facultad__universidad")

    def filtrar(self, queryset, datos):
        if datos.get("universidad"):
            queryset = queryset.filter(facultad__universidad=datos["universidad"])
        if datos.get("facultad"):
            queryset = queryset.filter(facultad=datos["facultad"])
        texto = datos.get("texto")
        if texto:
            queryset = queryset.filter(Q(codigo__icontains=texto) | Q(nombre__icontains=texto))
        return queryset


class CarreraCreateView(LoginRequiredMixin, UsuarioRegistroMixin, SuccessMessageMixin, CreateView):
    model = Carrera
    form_class = CarreraForm
    template_name = "academico/carrera_form.html"
    success_url = reverse_lazy("academico:carrera_lista")
    success_message = "Carrera creada correctamente."


class CarreraUpdateView(LoginRequiredMixin, UsuarioRegistroMixin, SuccessMessageMixin, UpdateView):
    model = Carrera
    form_class = CarreraForm
    template_name = "academico/carrera_form.html"
    success_url = reverse_lazy("academico:carrera_lista")
    success_message = "Carrera actualizada correctamente."


class CarreraDetailView(LoginRequiredMixin, DetailView):
    model = Carrera
    template_name = "academico/carrera_detalle.html"
    context_object_name = "carrera"

    def get_queryset(self):
        return super().get_queryset().select_related("facultad__universidad")

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx["cursos"] = self.object.cursos.select_related("semestre").order_by("semestre__numero", "codigo")
        return ctx


class CarreraDeleteView(LoginRequiredMixin, DeleteView):
    model = Carrera
    template_name = "academico/carrera_eliminar.html"
    context_object_name = "carrera"
    success_url = reverse_lazy("academico:carrera_lista")

    def form_valid(self, form):
        try:
            response = super().form_valid(form)
            messages.success(self.request, "Carrera eliminada correctamente.")
            return response
        except ProtectedError:
            messages.error(self.request, "No se puede eliminar: tiene cursos o estudiantes asociados.")
            return redirect(self.success_url)


class CarreraPdfView(LoginRequiredMixin, ComprobantePdfMixin, DetailView):
    model = Carrera
    context_object_name = "carrera"
    template_pdf = "pdf/carrera_comprobante.html"
    nombre_archivo = "carrera"

    def get_queryset(self):
        return super().get_queryset().select_related("facultad__universidad")

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx["cursos"] = self.object.cursos.select_related("semestre").order_by("semestre__numero", "codigo")
        return ctx                                                                                               # ========================
# CRUD SEMESTRES
# ========================
class SemestreListView(LoginRequiredMixin, ExportarMixin, ListView):
    model = Semestre
    template_name = "academico/semestre_lista.html"
    context_object_name = "semestres"
    paginate_by = 12
    titulo_reporte = "Reporte de semestres"
    nombre_archivo = "semestres"
    campos_disponibles = [
        ("numero", "Número"),
        ("nombre", "Nombre"),
    ]
    campos_por_defecto = ["numero", "nombre"]


class SemestreCreateView(LoginRequiredMixin, UsuarioRegistroMixin, SuccessMessageMixin, CreateView):
    model = Semestre
    form_class = SemestreForm
    template_name = "academico/semestre_form.html"
    success_url = reverse_lazy("academico:semestre_lista")
    success_message = "Semestre creado correctamente."


class SemestreUpdateView(LoginRequiredMixin, UsuarioRegistroMixin, SuccessMessageMixin, UpdateView):
    model = Semestre
    form_class = SemestreForm
    template_name = "academico/semestre_form.html"
    success_url = reverse_lazy("academico:semestre_lista")
    success_message = "Semestre actualizado correctamente."


class SemestreDetailView(LoginRequiredMixin, DetailView):
    model = Semestre
    template_name = "academico/semestre_detalle.html"
    context_object_name = "semestre"

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx["cursos"] = self.object.cursos.select_related("carrera").order_by("carrera__nombre", "codigo")
        return ctx


class SemestreDeleteView(LoginRequiredMixin, DeleteView):
    model = Semestre
    template_name = "academico/semestre_eliminar.html"
    context_object_name = "semestre"
    success_url = reverse_lazy("academico:semestre_lista")

    def form_valid(self, form):
        try:
            response = super().form_valid(form)
            messages.success(self.request, "Semestre eliminado correctamente.")
            return response
        except ProtectedError:
            messages.error(self.request, "No se puede eliminar: tiene cursos asociados.")
            return redirect(self.success_url)


class SemestrePdfView(LoginRequiredMixin, ComprobantePdfMixin, DetailView):
    model = Semestre
    context_object_name = "semestre"
    template_pdf = "pdf/semestre_comprobante.html"
    nombre_archivo = "semestre"

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx["cursos"] = self.object.cursos.select_related("carrera").order_by("carrera__nombre", "codigo")
        return ctx


# ========================
# CRUD PERIODOS
# ========================
class PeriodoActivoMixin(UsuarioRegistroMixin):
    """Garantiza que solo exista un periodo activo a la vez."""
    def form_valid(self, form):
        with transaction.atomic():
            if form.cleaned_data.get("activo"):
                qs = Periodo.objects.all()
                if form.instance.pk:
                    qs = qs.exclude(pk=form.instance.pk)
                qs.update(activo=False)
            return super().form_valid(form)


class PeriodoListView(LoginRequiredMixin, ExportarMixin, ListView):
    model = Periodo
    template_name = "academico/periodo_lista.html"
    context_object_name = "periodos"
    paginate_by = 10
    filtro_form_class = FiltroPeriodoForm
    titulo_reporte = "Reporte de periodos académicos"
    nombre_archivo = "periodos"
    campos_disponibles = [
        ("nombre", "Nombre"),
        ("fecha_inicio", "Fecha inicio"),
        ("fecha_fin", "Fecha fin"),
        ("activo", "Activo"),
    ]
    campos_por_defecto = ["nombre", "fecha_inicio", "fecha_fin", "activo"]

    def filtrar(self, queryset, datos):
        activo = datos.get("activo")
        if activo == "1":
            queryset = queryset.filter(activo=True)
        elif activo == "0":
            queryset = queryset.filter(activo=False)
        if datos.get("anio"):
            queryset = queryset.filter(fecha_inicio__year=datos["anio"])
        return queryset


class PeriodoCreateView(LoginRequiredMixin, PeriodoActivoMixin, SuccessMessageMixin, CreateView):
    model = Periodo
    form_class = PeriodoForm
    template_name = "academico/periodo_form.html"
    success_url = reverse_lazy("academico:periodo_lista")
    success_message = "Periodo creado correctamente."


class PeriodoUpdateView(LoginRequiredMixin, PeriodoActivoMixin, SuccessMessageMixin, UpdateView):
    model = Periodo
    form_class = PeriodoForm
    template_name = "academico/periodo_form.html"
    success_url = reverse_lazy("academico:periodo_lista")
    success_message = "Periodo actualizado correctamente."


class PeriodoDetailView(LoginRequiredMixin, DetailView):
    model = Periodo
    template_name = "academico/periodo_detalle.html"
    context_object_name = "periodo"

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        secciones = self.object.secciones.select_related("curso", "profesor").annotate(num_inscritos=Count("matriculas"))
        ctx["secciones"] = secciones
        ctx["total_inscritos"] = sum(s.num_inscritos for s in secciones)
        return ctx


class PeriodoDeleteView(LoginRequiredMixin, DeleteView):
    model = Periodo
    template_name = "academico/periodo_eliminar.html"
    context_object_name = "periodo"
    success_url = reverse_lazy("academico:periodo_lista")

    def form_valid(self, form):
        try:
            response = super().form_valid(form)
            messages.success(self.request, "Periodo eliminado correctamente.")
            return response
        except ProtectedError:
            messages.error(self.request, "No se puede eliminar: tiene secciones asociadas.")
            return redirect(self.success_url)


class PeriodoPdfView(LoginRequiredMixin, ComprobantePdfMixin, DetailView):
    model = Periodo
    context_object_name = "periodo"
    template_pdf = "pdf/periodo_comprobante.html"
    nombre_archivo = "periodo"

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        secciones = self.object.secciones.select_related("curso", "profesor").annotate(num_inscritos=Count("matriculas"))
        ctx["secciones"] = secciones
        ctx["total_inscritos"] = sum(s.num_inscritos for s in secciones)
        return ctx


# ========================
# CRUD CURSOS
# ========================
class CursoListView(LoginRequiredMixin, ExportarMixin, ListView):
    model = Curso
    template_name = "academico/curso_lista.html"
    context_object_name = "cursos"
    paginate_by = 10
    filtro_form_class = FiltroCursoForm
    titulo_reporte = "Reporte de cursos"
    nombre_archivo = "cursos"
    campos_disponibles = [
        ("codigo", "Código"),
        ("nombre", "Curso"),
        ("carrera__nombre", "Carrera"),
        ("semestre", "Semestre"),
        ("creditos", "Créditos"),
    ]
    campos_por_defecto = ["codigo", "nombre", "carrera__nombre", "semestre", "creditos"]

    def get_queryset(self):
        return super().get_queryset().select_related("carrera", "semestre")

    def filtrar(self, queryset, datos):
        if datos.get("carrera"):
            queryset = queryset.filter(carrera=datos["carrera"])
        if datos.get("semestre"):
            queryset = queryset.filter(semestre=datos["semestre"])
        texto = datos.get("texto")
        if texto:
            queryset = queryset.filter(Q(codigo__icontains=texto) | Q(nombre__icontains=texto))
        return queryset


class CursoCreateView(LoginRequiredMixin, UsuarioRegistroMixin, SuccessMessageMixin, CreateView):
    model = Curso
    form_class = CursoForm
    template_name = "academico/curso_form.html"
    success_url = reverse_lazy("academico:curso_lista")
    success_message = "Curso creado correctamente."


class CursoUpdateView(LoginRequiredMixin, UsuarioRegistroMixin, SuccessMessageMixin, UpdateView):
    model = Curso
    form_class = CursoForm
    template_name = "academico/curso_form.html"
    success_url = reverse_lazy("academico:curso_lista")
    success_message = "Curso actualizado correctamente."


class CursoDetailView(LoginRequiredMixin, DetailView):
    model = Curso
    template_name = "academico/curso_detalle.html"
    context_object_name = "curso"

    def get_queryset(self):
        return super().get_queryset().select_related("carrera", "semestre")

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx["secciones"] = self.object.secciones.select_related("periodo", "profesor").annotate(num_inscritos=Count("matriculas"))
        return ctx


class CursoDeleteView(LoginRequiredMixin, DeleteView):
    model = Curso
    template_name = "academico/curso_eliminar.html"
    context_object_name = "curso"
    success_url = reverse_lazy("academico:curso_lista")

    def form_valid(self, form):
        try:
            response = super().form_valid(form)
            messages.success(self.request, "Curso eliminado correctamente.")
            return response
        except ProtectedError:
            messages.error(self.request, "No se puede eliminar: tiene secciones asociadas.")
            return redirect(self.success_url)


class CursoPdfView(LoginRequiredMixin, ComprobantePdfMixin, DetailView):
    model = Curso
    context_object_name = "curso"
    template_pdf = "pdf/curso_comprobante.html"
    nombre_archivo = "curso"

    def get_queryset(self):
        return super().get_queryset().select_related("carrera", "semestre")

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx["secciones"] = self.object.secciones.select_related("periodo", "profesor").annotate(num_inscritos=Count("matriculas"))
        return ctx                                                 # ========================
# CRUD SECCIONES
# ========================
class SeccionListView(LoginRequiredMixin, ExportarMixin, ListView):
    model = Seccion
    template_name = "academico/seccion_lista.html"
    context_object_name = "secciones"
    paginate_by = 10
    filtro_form_class = FiltroSeccionForm
    titulo_reporte = "Reporte de secciones"
    nombre_archivo = "secciones"
    campos_disponibles = [
        ("curso", "Curso"),
        ("paralelo", "Paralelo"),
        ("jornada", "Jornada"),
        ("profesor", "Profesor"),
        ("cupo", "Cupo"),
        ("inscritos", "Inscritos"),
    ]
    campos_por_defecto = [
        "curso",
        "paralelo",
        "jornada",
        "profesor",
        "cupo",
        "inscritos",
    ]

    def get_queryset(self):
        return super().get_queryset().select_related("curso__carrera", "periodo", "profesor")

    def filtrar(self, queryset, datos):
        if datos.get("periodo"):
            queryset = queryset.filter(periodo=datos["periodo"])
        if datos.get("carrera"):
            queryset = queryset.filter(curso__carrera=datos["carrera"])
        if datos.get("jornada"):
            queryset = queryset.filter(jornada=datos["jornada"])
        if datos.get("profesor"):
            queryset = queryset.filter(profesor=datos["profesor"])
        return queryset


class SeccionCreateView(LoginRequiredMixin, UsuarioRegistroMixin, SuccessMessageMixin, CreateView):
    model = Seccion
    form_class = SeccionForm
    template_name = "academico/seccion_form.html"
    success_url = reverse_lazy("academico:seccion_lista")
    success_message = "Sección creada correctamente."


class SeccionUpdateView(LoginRequiredMixin, UsuarioRegistroMixin, SuccessMessageMixin, UpdateView):
    model = Seccion
    form_class = SeccionForm
    template_name = "academico/seccion_form.html"
    success_url = reverse_lazy("academico:seccion_lista")
    success_message = "Sección actualizada correctamente."


class SeccionDetailView(LoginRequiredMixin, DetailView):
    model = Seccion
    template_name = "academico/seccion_detalle.html"
    context_object_name = "seccion"

    def get_queryset(self):
        return super().get_queryset().select_related("curso__carrera", "periodo", "profesor")

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx["matriculas"] = (
            self.object.matriculas.select_related("estudiante", "nota")
            .order_by("estudiante__apellidos", "estudiante__nombres")
        )
        return ctx


class SeccionDeleteView(LoginRequiredMixin, DeleteView):
    model = Seccion
    template_name = "academico/seccion_eliminar.html"
    context_object_name = "seccion"
    success_url = reverse_lazy("academico:seccion_lista")

    def form_valid(self, form):
        try:
            response = super().form_valid(form)
            messages.success(self.request, "Sección eliminada correctamente.")
            return response
        except ProtectedError:
            messages.error(self.request, "No se puede eliminar: tiene estudiantes matriculados.")
            return redirect(self.success_url)


class SeccionPdfView(LoginRequiredMixin, ComprobantePdfMixin, DetailView):
    model = Seccion
    context_object_name = "seccion"
    template_pdf = "pdf/seccion_comprobante.html"
    nombre_archivo = "seccion"

    def get_queryset(self):
        return super().get_queryset().select_related(
            "curso__carrera__facultad__universidad",
            "periodo",
            "profesor",
        )

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx["matriculas"] = (
            self.object.matriculas.select_related("estudiante", "nota")
            .order_by("estudiante__apellidos", "estudiante__nombres")
        )
        return ctx

@login_required
def matricular_varios(request, pk):
    seccion = get_object_or_404(Seccion, pk=pk)
    disponibles = Estudiante.objects.filter(
        carrera_id=seccion.curso.carrera_id
    ).exclude(
        pk__in=seccion.matriculas.values_list("estudiante_id", flat=True)
    ).order_by("apellidos", "nombres")

    formulario = forms.Form(
        request.POST if request.method == "POST" else None
    )
    formulario.fields["estudiantes"] = forms.ModelMultipleChoiceField(
        queryset=disponibles,
        widget=forms.CheckboxSelectMultiple,
        label="Estudiantes",
    )

    if request.method == "POST" and formulario.is_valid():
        estudiantes = formulario.cleaned_data["estudiantes"]

        try:
            with transaction.atomic():
                for estudiante in estudiantes:
                    matricula = Matricula(
                        estudiante=estudiante,
                        seccion=seccion,
                        user=request.user,
                    )
                    matricula.full_clean()
                    matricula.save()
        except ValidationError as error:
            formulario.add_error(None, error.messages)
        else:
            messages.success(request, "Se guardaron las matrículas seleccionadas.")
            return redirect("academico:seccion_detalle", pk=seccion.pk)

    return render(
        request,
        "academico/matricular_varios.html",
        {"seccion": seccion, "form": formulario},
    )
@login_required
def registrar_notas_seccion(request, pk):
    seccion = get_object_or_404(Seccion, pk=pk)
    matriculas = seccion.matriculas.select_related(
        "estudiante", "nota"
    ).order_by("estudiante__apellidos", "estudiante__nombres", "pk")

    datos = request.POST if request.method == "POST" else None
    filas = []

    for matricula in matriculas:
        nota = getattr(matricula, "nota", None)
        formulario = NotaInlineForm(
            datos,
            instance=nota,
            prefix=f"nota-{matricula.pk}",
            initial={"n1": None, "n2": None, "n3": None} if nota is None else None,
        )
        filas.append((matricula, formulario))

    if request.method == "POST":
        pendientes = [
            (matricula, formulario)
            for matricula, formulario in filas
            if formulario.has_changed()
        ]
        resultados = [
            formulario.is_valid()
            for _, formulario in pendientes
        ]

        if all(resultados):
            if pendientes:
                with transaction.atomic():
                    for matricula, formulario in pendientes:
                        nota = formulario.save(commit=False)
                        nota.matricula = matricula
                        nota.user = request.user
                        nota.save()

                messages.success(request, "Se guardaron las calificaciones.")
            else:
                messages.info(request, "No hay cambios para guardar.")

            return redirect("academico:registrar_notas_seccion", pk=seccion.pk)

    return render(
        request,
        "academico/registrar_notas_seccion.html",
        {"seccion": seccion, "filas": filas},
    )