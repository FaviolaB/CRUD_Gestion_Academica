from .utils import exportar_excel, renderizar_pdf, valor_campo

class UsuarioRegistroMixin:
    """Asigna automáticamente el usuario autenticado al crear o editar un registro."""
    def form_valid(self, form):
        if hasattr(form.instance, "user"):
            form.instance.user = self.request.user
        elif hasattr(form.instance, "usuario_registro"):
            form.instance.usuario_registro = self.request.user
        return super().form_valid(form)


class FiltroCamposMixin:
    """Componente reutilizable de filtros y selección dinámica de columnas."""
    filtro_form_class = None
    campos_disponibles = []
    campos_por_defecto = []

    def filtrar(self, queryset, datos):
        return queryset

    def get_queryset(self):
        qs = super().get_queryset()
        self.filtro_form = None
        if self.filtro_form_class:
            self.filtro_form = self.filtro_form_class(self.request.GET or None)
            if self.filtro_form.is_valid():
                qs = self.filtrar(qs, self.filtro_form.cleaned_data)
        return qs

    def get_campos_seleccionados(self):
        validos = {ruta for ruta, _ in self.campos_disponibles}
        elegidos = [c for c in self.request.GET.getlist("campos") if c in validos]
        if elegidos:
            return elegidos
        if self.campos_por_defecto:
            return [c for c in self.campos_por_defecto if c in validos]
        return [ruta for ruta, _ in self.campos_disponibles]

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        seleccionados = self.get_campos_seleccionados()
        mapa_titulos = dict(self.campos_disponibles)

        params = self.request.GET.copy()
        params.pop("page", None)
        params.pop("exportar", None)

        ctx["filtro_form"] = self.filtro_form
        ctx["campos_disponibles"] = self.campos_disponibles
        ctx["campos_seleccionados"] = seleccionados
        ctx["encabezados"] = [mapa_titulos[c] for c in seleccionados]
        ctx["filas"] = [
            (obj, [valor_campo(obj, c) for c in seleccionados])
            for obj in ctx["object_list"]
        ]
        ctx["consulta"] = params.urlencode()
        return ctx


class ExportarMixin(FiltroCamposMixin):
    """Extiende FiltroCamposMixin agregando exportación a Excel y PDF."""
    titulo_reporte = "Reporte"
    nombre_archivo = "reporte"
    def get_nombre_archivo(self):
        return self.nombre_archivo
    
    def render_to_response(self, context, **response_kwargs):
        exportar = self.request.GET.get("exportar")
        if exportar in ("excel", "pdf"):
            seleccionados = self.get_campos_seleccionados()
            mapa_titulos = dict(self.campos_disponibles)
            columnas = [(c, mapa_titulos[c]) for c in seleccionados]
            qs = self.get_queryset()

            if exportar == "excel":
                return exportar_excel(
                    self.titulo_reporte,
                    columnas,
                    qs,
                    nombre_archivo=self.get_nombre_archivo(),
                )
            if exportar == "pdf":
                filas = [
                    [valor_campo(obj, campo) for campo in seleccionados]
                    for obj in qs
                ]

                filtros = []
                if self.filtro_form is not None and self.filtro_form.is_valid():
                    for nombre, valor in self.filtro_form.cleaned_data.items():
                        if valor is not None and valor != "":
                            campo = self.filtro_form.fields[nombre]
                            opciones = dict(getattr(campo, "choices", []))
                            etiqueta = campo.label or nombre
                            texto = opciones.get(valor, valor)
                            filtros.append(f"{etiqueta}: {texto}")

                return renderizar_pdf(
                    "pdf/listado_pdf.html",
                    {
                        "titulo": self.titulo_reporte,
                        "columnas": [etiqueta for _, etiqueta in columnas],
                        "filas": filas,
                        "filtros": filtros,
                        "generado_por": self.request.user.get_username(),
                    },
                    nombre_archivo=self.get_nombre_archivo(),        
                )
        return super().render_to_response(context, **response_kwargs)


class ComprobantePdfMixin:
    """Renderiza un DetailView directamente como documento PDF descargable/imprimible."""
    template_pdf = ""
    nombre_archivo = "comprobante"

    def render_to_response(self, context, **response_kwargs):
        archivo = f"{self.nombre_archivo}_{self.object.pk}"
        return renderizar_pdf(
            self.template_pdf,
            context,
            nombre_archivo=archivo,
        )