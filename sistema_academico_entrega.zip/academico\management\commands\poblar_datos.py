from datetime import date
from decimal import Decimal

from django.core.management.base import BaseCommand
from academico.models import (
    Universidad, Facultad, Carrera, Semestre, Periodo,
    Curso, Profesor, Estudiante, Seccion, Matricula, Nota, Jornada
)


class Command(BaseCommand):
    help = "Crea datos de prueba para el sistema académico sin duplicarlos"

    def handle(self, *args, **options):
        # 1. Universidades (2)
        ug, _ = Universidad.objects.get_or_create(
            nombre="Universidad de Guayaquil",
            defaults={"siglas": "UG", "ciudad": "Guayaquil"}
        )
        espol, _ = Universidad.objects.get_or_create(
            nombre="Escuela Superior Politécnica del Litoral",
            defaults={"siglas": "ESPOL", "ciudad": "Guayaquil"}
        )

        # 2. Facultades (3)
        fcmf, _ = Facultad.objects.get_or_create(
            universidad=ug, nombre="Ciencias Matemáticas y Físicas",
            defaults={"decano": "Dr. Roberto Andrade"}
        )
        fii, _ = Facultad.objects.get_or_create(
            universidad=ug, nombre="Ingeniería Industrial",
            defaults={"decano": "Ing. Laura Méndez"}
        )
        fiec, _ = Facultad.objects.get_or_create(
            universidad=espol, nombre="Ing. en Electricidad y Computación",
            defaults={"decano": "PhD. Carlos Salgado"}
        )

        # 3. Carreras (3)
        sof, _ = Carrera.objects.get_or_create(
            codigo="SOF",
            defaults={"facultad": fcmf, "nombre": "Ingeniería de Software", "duracion_semestres": 8}
        )
        red, _ = Carrera.objects.get_or_create(
            codigo="RED",
            defaults={"facultad": fcmf, "nombre": "Redes y Telecomunicaciones", "duracion_semestres": 8}
        )
        ind, _ = Carrera.objects.get_or_create(
            codigo="IND",
            defaults={"facultad": fii, "nombre": "Ingeniería Industrial", "duracion_semestres": 10}
        )

        # 4. Semestres (2)
        s1, _ = Semestre.objects.get_or_create(numero=1, defaults={"nombre": "Primer semestre"})
        s2, _ = Semestre.objects.get_or_create(numero=2, defaults={"nombre": "Segundo semestre"})

        # 5. Periodo activo (1)
        periodo, _ = Periodo.objects.get_or_create(
            nombre="2026-1",
            defaults={
                "fecha_inicio": date(2026, 4, 1),
                "fecha_fin": date(2026, 8, 31),
                "activo": True
            }
        )

        # 6. Cursos (6)
        c1, _ = Curso.objects.get_or_create(codigo="SOF-101", defaults={"carrera": sof, "semestre": s1, "nombre": "Programación I", "creditos": 4})
        c2, _ = Curso.objects.get_or_create(codigo="SOF-102", defaults={"carrera": sof, "semestre": s1, "nombre": "Matemática Discreta", "creditos": 3})
        c3, _ = Curso.objects.get_or_create(codigo="SOF-201", defaults={"carrera": sof, "semestre": s2, "nombre": "Base de Datos I", "creditos": 4})
        c4, _ = Curso.objects.get_or_create(codigo="RED-101", defaults={"carrera": red, "semestre": s1, "nombre": "Fundamentos de Redes", "creditos": 4})
        c5, _ = Curso.objects.get_or_create(codigo="RED-201", defaults={"carrera": red, "semestre": s2, "nombre": "Enrutamiento", "creditos": 3})
        c6, _ = Curso.objects.get_or_create(codigo="IND-101", defaults={"carrera": ind, "semestre": s1, "nombre": "Cálculo Diferencial", "creditos": 4})

        # 7. Profesores (3)
        p1, _ = Profesor.objects.get_or_create(cedula="0911111111", defaults={"nombres": "Carlos", "apellidos": "Vera", "email": "cvera@ug.edu.ec", "titulo": "Mg. en Software"})
        p2, _ = Profesor.objects.get_or_create(cedula="0922222222", defaults={"nombres": "María", "apellidos": "León", "email": "mleon@ug.edu.ec", "titulo": "Ing. en Sistemas"})
        p3, _ = Profesor.objects.get_or_create(cedula="0933333333", defaults={"nombres": "Jorge", "apellidos": "Pazmiño", "email": "jpazmino@ug.edu.ec", "titulo": "PhD. en Computación"})

        # 8. Secciones (4: diurnas y nocturnas)
        sec1, _ = Seccion.objects.get_or_create(curso=c1, periodo=periodo, paralelo="A", jornada=Jornada.DIURNA, defaults={"profesor": p1, "cupo": 30})
        sec2, _ = Seccion.objects.get_or_create(curso=c1, periodo=periodo, paralelo="B", jornada=Jornada.NOCTURNA, defaults={"profesor": p2, "cupo": 25})
        sec3, _ = Seccion.objects.get_or_create(curso=c4, periodo=periodo, paralelo="A", jornada=Jornada.DIURNA, defaults={"profesor": p3, "cupo": 30})
        sec4, _ = Seccion.objects.get_or_create(curso=c6, periodo=periodo, paralelo="A", jornada=Jornada.NOCTURNA, defaults={"profesor": p1, "cupo": 30})
        sec5, _ = Seccion.objects.get_or_create(curso=c2, periodo=periodo, paralelo="A", jornada=Jornada.DIURNA, defaults={"profesor": p2, "cupo": 30})

        # 9. Estudiantes (15)
        datos_estudiantes = [
            ("0910000001", "Ana", "Pérez", sof), ("0910000002", "Luis", "Mora", sof),
            ("0910000003", "Eva", "Ruiz", sof), ("0910000004", "Pedro", "Gómez", sof),
            ("0910000005", "Sofía", "Castro", sof), ("0910000006", "Diego", "Ortiz", sof),
            ("0910000007", "Carla", "Silva", red), ("0910000008", "Mateo", "Reyes", red),
            ("0910000009", "Lucía", "Vargas", red), ("0910000010", "Andrés", "Torres", red),
            ("0910000011", "Valeria", "Ríos", ind), ("0910000012", "Javier", "Suárez", ind),
            ("0910000013", "Camila", "Navarro", ind), ("0910000014", "Daniel", "Cedeño", ind),
            ("0910000015", "Elena", "Mendoza", ind),
        ]
        estudiantes = []
        for ced, nom, ape, car in datos_estudiantes:
            est, _ = Estudiante.objects.get_or_create(
                cedula=ced,
                defaults={
                    "nombres": nom,
                    "apellidos": ape,
                    "email": f"{nom.lower()}.{ape.lower()}@est.ug.edu.ec",
                    "telefono": "0991234567",
                    "carrera": car
                }
            )
            estudiantes.append(est)

        # 10. Matrículas (25 exactas, respetando la carrera de cada estudiante)
        parejas = []
        for est in estudiantes:
            if est.carrera == sof:
                parejas.extend([(est, sec1), (est, sec2)])  # 6 estudiantes * 2 secciones = 12
            elif est.carrera == red:
                parejas.append((est, sec3))                 # 4 estudiantes * 1 sección = 4
            elif est.carrera == ind:
                parejas.append((est, sec4))                 # 5 estudiantes * 1 sección = 5
        # Sumamos 4 más de Software en sec5 para llegar a 25 matrículas
        for est in estudiantes[:4]:
            parejas.append((est, sec5))

        notas_ejemplo = [
            (Decimal("85.00"), Decimal("78.00"), Decimal("90.00")),  # Aprobado (84.33)
            (Decimal("60.00"), Decimal("55.00"), Decimal("62.00")),  # Reprobado (59.00)
            (Decimal("70.00"), Decimal("70.00"), Decimal("70.00")),  # Aprobado justo (70.00)
            (Decimal("92.00"), Decimal("88.00"), Decimal("95.00")),  # Aprobado (91.67)
            (Decimal("45.00"), Decimal("68.00"), Decimal("60.00")),  # Reprobado (57.67)
        ]

        for idx, (est, sec) in enumerate(parejas):
            mat, creada = Matricula.objects.get_or_create(estudiante=est, seccion=sec)
            # Creamos nota en 23 matrículas y dejamos 2 sin nota para probar casos vacíos
            if creada and idx < len(parejas) - 2:
                n1, n2, n3 = notas_ejemplo[idx % len(notas_ejemplo)]
                Nota.objects.create(matricula=mat, n1=n1, n2=n2, n3=n3)

        self.stdout.write(self.style.SUCCESS("Datos de prueba creados correctamente."))