import io
from pathlib import Path
from urllib.parse import unquote, urlsplit

from django.conf import settings
from django.contrib.staticfiles import finders
from django.http import HttpResponse
from django.template.loader import get_template
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill
from xhtml2pdf import pisa


def valor_campo(objeto, ruta):
    """Lee un campo, una propiedad o una relación separada por '__'."""
    actual = objeto

    for parte in ruta.split("__"):
        if actual is None:
            return ""

        metodo_display = getattr(actual, f"get_{parte}_display", None)
        if callable(metodo_display):
            actual = metodo_display()
        else:
            actual = getattr(actual, parte, None)
            if callable(actual):
                actual = actual()

    if actual is None:
        return ""
    if isinstance(actual, bool):
        return "Sí" if actual else "No"
    return str(actual)


# Alias para las vistas que usan el nombre anterior.
obtener_valor = valor_campo


def exportar_excel(titulo, columnas, filas, nombre_archivo="reporte"):
    """Genera un archivo XLSX descargable."""
    libro = Workbook()
    hoja = libro.active
    hoja.title = titulo[:31]

    hoja.append([etiqueta for _, etiqueta in columnas])

    relleno = PatternFill(
        start_color="1E3A8A",
        end_color="1E3A8A",
        fill_type="solid",
    )
    fuente_blanca = Font(color="FFFFFF", bold=True)

    for celda in hoja[1]:
        celda.fill = relleno
        celda.font = fuente_blanca

    for objeto in filas:
        hoja.append([valor_campo(objeto, campo) for campo, _ in columnas])

    for columna in hoja.columns:
        ancho = max(len(str(celda.value or "")) for celda in columna)
        hoja.column_dimensions[columna[0].column_letter].width = min(ancho + 4, 45)

    buffer = io.BytesIO()
    libro.save(buffer)

    respuesta = HttpResponse(
        buffer.getvalue(),
        content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    )
    respuesta["Content-Disposition"] = f'attachment; filename="{nombre_archivo}.xlsx"'
    return respuesta


def enlazar_archivos(uri, _ruta_relativa):
    """Convierte las URL de archivos subidos y estáticos en rutas locales."""
    ruta = unquote(urlsplit(uri).path).lstrip("/")
    prefijo_media = urlsplit(settings.MEDIA_URL or "").path.lstrip("/")
    prefijo_estatico = urlsplit(settings.STATIC_URL or "").path.lstrip("/")

    if prefijo_media and ruta.startswith(prefijo_media):
        carpeta_media = Path(settings.MEDIA_ROOT).resolve()
        ruta_relativa = ruta[len(prefijo_media):]
        archivo = (carpeta_media / ruta_relativa).resolve()

        if archivo.is_relative_to(carpeta_media) and archivo.is_file():
            return str(archivo)

    if prefijo_estatico and ruta.startswith(prefijo_estatico):
        ruta_relativa = Path(ruta[len(prefijo_estatico):])

        if not ruta_relativa.anchor and ".." not in ruta_relativa.parts:
            archivo = finders.find(ruta_relativa.as_posix())
            if archivo:
                return archivo

    return uri


def renderizar_pdf(template_src, contexto, nombre_archivo="documento"):
    """Convierte una plantilla de Django en un PDF."""
    plantilla = get_template(template_src)
    html = plantilla.render(contexto)
    buffer = io.BytesIO()

    resultado = pisa.CreatePDF(
        io.BytesIO(html.encode("utf-8")),
        dest=buffer,
        encoding="utf-8",
        link_callback=enlazar_archivos,
    )

    if resultado.err:
        return HttpResponse("Error al generar el PDF", status=500)

    respuesta = HttpResponse(buffer.getvalue(), content_type="application/pdf")
    respuesta["Content-Disposition"] = f'inline; filename="{nombre_archivo}.pdf"'
    return respuesta