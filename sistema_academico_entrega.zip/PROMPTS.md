# Bitácora de prompts — Sistema Académico

## Prompt 0 — Contexto del proyecto

Usé este prompt al iniciar las conversaciones para dar el contexto del
Sistema Académico en Django. Indiqué que quería avanzar paso a paso y
recibir el código por archivo, con su ruta y una indicación de qué agregar
o reemplazar.

## Prompt 1 — Modelos del sistema

Pedí crear el modelo base y los 11 modelos académicos, con sus relaciones,
validaciones y el cálculo del promedio y estado de las notas.

**Verificación.** El proyecto contiene los 11 modelos y su migración inicial.
En la revisión, Django no detectó cambios de modelos pendientes de migrar.

## Prompt 2 — Administración y datos de prueba

Pedí registrar los modelos en el administrador de Django, incluir la nota
dentro del formulario de matrícula y crear el comando `poblar_datos`.

**Verificación.** El comando está en el proyecto y la base de prueba contiene
15 estudiantes, 5 secciones, 25 matrículas y 23 notas.

## Prompt 3 — Base del proyecto

Pedí preparar el inicio de sesión, el menú, la plantilla base y el panel
principal con los indicadores del sistema.

**Qué falló y cómo lo corregí.** El formulario de inicio de sesión no se
veía. Lo coloqué dentro del bloque `contenido`. El panel mostraba 0,0 %
porque buscaba un estado de nota incorrecto. Importé `EstadoNota` desde
`.models` y usé `EstadoNota.APROBADO`. El panel mostró 60,9 %.
También agregué el bloque `scripts` al final de `base.html`.

## Prompt 4 — CRUD básico de Estudiantes

Pedí el listado, el formulario para crear y editar, la vista de detalle y
la confirmación de eliminación. El formulario debía permitir cargar una
foto y validar la cédula.

**Verificación.** Las pantallas abrieron durante la revisión. Desde Editar
cargué una foto y luego confirmé que aparecía en la ficha PDF.

## Prompt 5 — Filtros y selección de columnas

Pedí un componente reutilizable para combinar filtros, seleccionar columnas
y conservar esas opciones al pasar de página.

**Verificación.** En Estudiantes se comprobó que se podían combinar los
filtros de texto y carrera y seleccionar tres columnas.

## Prompt 6 — Exportar a Excel

Pedí exportar todos los registros del listado filtrado, con las columnas
seleccionadas.

**Verificación.** El Excel de Estudiantes exportó los 15 registros al
quitar los filtros. Al combinar dos filtros y elegir tres columnas,
el archivo respetó esa selección.

## Prompt 7 — PDF del listado

Pedí generar un PDF con las mismas filas y columnas del listado, los
filtros aplicados, el usuario y la numeración de páginas.

**Qué faltaba y cómo lo corregí.** El PDF ya mostraba la tabla. Agregué
el usuario y los filtros desde `ExportarMixin`, configuré la repetición
de encabezados y agregué el pie «Página X de Y».

**Verificación.** En Matrículas, Nocturna y Reprobado dieron cinco registros.
Al exportar sin filtros, el PDF mostró 25 registros, repitió los encabezados
y mostró «Página 1 de 2» en la primera hoja.

## Prompt 8 — Ficha PDF del estudiante

Pedí una ficha individual con los datos del estudiante, su foto, el logo
de la universidad y el historial de matrículas y calificaciones.

**Qué faltaba y cómo lo corregí.** Agregué el logo y la foto a la plantilla,
configuré `link_callback` para localizar las imágenes y ajusté los campos
de la sección y de las notas.

**Verificación.** La ficha de Sofía Castro mostró el logo de la Universidad
de Guayaquil, la foto, las notas, los promedios y los estados.

## Prompt 9 — CRUD de Matrícula con su Nota

Pedí crear y editar una matrícula junto con su nota en el mismo formulario.
La matrícula debía validar la carrera del estudiante y el cupo de la
sección. La nota debía calcular el promedio y el estado.

**Verificación.** El formulario y el detalle abrieron durante la revisión.
En los comprobantes se mostraron notas, promedios y estados calculados.

## Prompt 10 — Filtros, columnas y exportaciones de Matrículas

Pedí reutilizar los componentes de filtros, columnas, Excel y PDF en
Matrículas, con opciones como jornada, estado y rango de promedio.

**Verificación.** El PDF filtrado por Nocturna y Reprobado mostró cinco
matrículas que cumplían ambas condiciones. También se probó la exportación
a Excel del listado.

## Prompt 11 — Comprobante PDF de Matrícula

Pedí un comprobante individual con los datos del estudiante y de la
sección, las notas, el promedio, el estado y los espacios para firmas.

**Qué falló y cómo lo corregí.** Django buscaba la plantilla en una ruta
equivocada. Cambié la ruta a `pdf/matricula_comprobante.html` y usé
`matricula.seccion.paralelo` en la plantilla.

**Verificación.** El comprobante N.º 1 abrió con las tres notas, el promedio
84,33 y el estado Aprobado en verde.

## Unidad 6 — Prompt plantilla aplicado a los ocho módulos

Usé el prompt plantilla por separado para cada módulo. Pedí su CRUD,
filtros y columnas según la tabla de la guía, exportaciones, comprobante
PDF y enlace en el menú.

**Qué falló y cómo lo corregí.** Las vistas de los comprobantes buscaban
las plantillas en `academico/pdf/`. Corregí las rutas a `pdf/`.
Además, la plantilla de Universidad estaba vacía y la completé.

| Aplicación del prompt | Comprobante verificado |
|---|---|
| Universidad | Ficha de la Universidad de Guayaquil con facultades y carreras. |
| Facultad | Ficha de Ciencias Matemáticas y Físicas con su decano y carreras. |
| Carrera | Malla de Ingeniería de Software con cursos agrupados por semestre. |
| Semestre | Listado de cursos del primer semestre con carrera y créditos. |
| Periodo | Resumen de 2026-1 con cinco secciones y 25 inscritos. |
| Curso | Ficha de Programación I con sus secciones diurna y nocturna. |
| Profesor | Carga académica de Vera Carlos con sus secciones e inscritos. |
| Sección | Acta de Programación I, paralelo A, con seis estudiantes y sus notas. |

## Prompts de apoyo y corrección

Usé preguntas de seguimiento para revisar los errores de Django, ubicar
los cambios en cada archivo y pedir el código completo de las plantillas
cuando necesitaba comparar el resultado.

**Ejemplo de corrección.** Al editar `views.py`, dos asignaciones quedaron
juntas y Python mostró un `SyntaxError`. Separé `template_pdf` y
`nombre_archivo` en dos líneas con la misma sangría.

## Punto 7.1 — Retos del Sistema Académico

### 1. Aprobados y reprobados del periodo activo

**Qué pedí:** Mostrar en el panel principal cuántas notas aprobadas y reprobadas hay en el periodo activo.

**Qué cambié:** En `InicioView` filtré las notas por el periodo activo y envié los dos conteos a la plantilla del panel. Los mostré debajo del porcentaje general de aprobación.

**Cómo lo probé:** Recargué el inicio y comprobé que para el periodo 2026-1 aparecían 14 aprobados y 9 reprobados. El porcentaje general seguía mostrando 60,9 %.

### 2. Matricular a varios estudiantes desde una sección

**Qué pedí:** Agregar una opción para seleccionar y matricular a varios estudiantes desde el detalle de una sección.

**Qué cambié:** Agregué el botón «Matricular varios» y un formulario que muestra a los estudiantes de la carrera del curso que todavía no están inscritos en esa sección. El sistema valida cada matrícula y guarda el grupo en una sola operación.

**Cómo lo probé:** Primero abrí el formulario en una sección donde ya estaban inscritos todos los estudiantes disponibles de esa carrera. Después creé otro paralelo de Cálculo Diferencial, seleccioné a dos estudiantes y comprobé que la sección pasó de 0 a 2 inscritos.

### 3. Registrar las notas de una sección en una tabla

**Qué pedí:** Poder ingresar las notas de varios estudiantes de una sección y guardarlas con un solo clic.

**Qué cambié:** Agregué el botón «Registrar notas» en el detalle de la sección. Reutilicé el formulario de notas para mostrar una fila por estudiante con N1, N2 y N3. Al guardar, el sistema calcula el promedio y el estado de cada nota.

**Cómo lo probé:** Abrí la tabla de calificaciones, ingresé notas para dos estudiantes de la sección de prueba y confirmé que se guardaron desde el mismo formulario.

### 4. Promedio general en el récord académico

**Qué pedí:** Mostrar el promedio general del estudiante al final de su ficha PDF.

**Qué corregí:** Al principio salía «Sin calificaciones» aunque la tabla mostraba dos materias con notas. Agregué el cálculo con `Avg` en `EstudianteDetailView` y pasé el resultado a la plantilla del PDF.

**Cómo lo probé:** Volví a generar la ficha de Sofía Castro. Con los promedios 91,67 y 57,67, la ficha mostró un promedio general de 74,67.

### 5. Nombre de la exportación según el filtro

**Qué pedí:** Incluir en el nombre del archivo la carrera seleccionada al exportar el listado de estudiantes.

**Qué cambié:** Agregué el método `get_nombre_archivo()` al componente de exportación. En el listado de estudiantes lo adapté para añadir el nombre de la carrera cuando ese filtro está aplicado.

**Cómo lo probé:** Filtré por Ingeniería de Software, exporté a Excel y comprobé que el archivo se llamaba `estudiantes-ingenieria-de-software.xlsx`.

### 6. Permiso de eliminación para Secretaría

**Qué pedí:** Restringir la eliminación de estudiantes para que la cuenta de Secretaría pueda acceder a esa acción.

**Qué cambié:** Agregué `PermissionRequiredMixin` a `EstudianteDeleteView` y configuré el permiso `academico.delete_estudiante`. En el administrador de Django asigné ese permiso al grupo Secretaría.

**Cómo lo probé:** Entré con la cuenta autorizada y confirmé que se abrió la pantalla de confirmación de borrado. Queda por comprobar que una cuenta sin ese permiso reciba un error 403.