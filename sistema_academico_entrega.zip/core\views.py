from django.shortcuts import render

# Create your views here.
from django.contrib.auth.mixins import LoginRequiredMixin
from django.views.generic import TemplateView

from academico.models import Carrera, Curso, Estudiante, Matricula, Periodo, Profesor, Seccion


class InicioView(LoginRequiredMixin, TemplateView):
    template_name = "inicio.html"

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx["periodo_activo"] = Periodo.objects.filter(activo=True).first()
        ctx["totales"] = {
            "carreras": Carrera.objects.count(),
            "cursos": Curso.objects.count(),
            "profesores": Profesor.objects.count(),
            "estudiantes": Estudiante.objects.count(),
            "secciones": Seccion.objects.count(),
            "matriculas": Matricula.objects.count(),
        }
        return ctx